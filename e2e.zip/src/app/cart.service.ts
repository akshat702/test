import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  private data = [
    {
      category: 'Pizza',
      expanded: true,
      products: [
        { id: 0, name: 'Salami', price: '8'},
        { id: 1, name: 'Classic', price: '9'},
        { id: 2, name: 'Tuna', price: '11'},
        { id: 3, name: 'Hawai', price: '10'}
      ]
    },
    {
      category: 'Pasta',
      products: [
        { id: 4, name: 'Mac & Cheese', price: '80'},
        { id: 5, name: 'Bolognese', price: '90'}
      ]
    },
    {
      category: 'Salad',
      products: [
        { id: 6, name: 'Ham & Egg', price: '80'},
        { id: 7, name: 'Basic', price: '9'},
        { id: 8, name: 'Basic1', price: '10'},
        { id: 9, name: 'Basic23', price: '11'},
        { id: 10, name: 'Basic42423', price: '15'}
      ]
    }
  ];

  private cart = [];
  constructor() { }

  getProducts() {
    return this.data;
  }

  getCart() {
    return this.cart;
  }

  addProduct(product) {
    this.cart.push(product);
  }
}
